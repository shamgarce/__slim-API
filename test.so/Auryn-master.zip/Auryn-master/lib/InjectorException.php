<?php

namespace Auryn;

class InjectorException extends \Exception {}
