<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body><h1>
        <?php
        echo $msg;
        ?></h1>
    </body>
</html>
