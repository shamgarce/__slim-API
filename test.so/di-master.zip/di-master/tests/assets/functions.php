<?php
namespace OrnoTest\Assets;

function sayHi()
{
    return 'hi';
}