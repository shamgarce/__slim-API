<?php
/**
 * The Orno Component Library
 *
 * @author  Phil Bennett @philipobenito
 * @license MIT (see the LICENSE file)
 */
namespace OrnoTest\Assets;

/**
 * FooWithNoDefaultArg
 */
class FooWithNoDefaultArg
{
    public function __construct($name)
    {

    }
}
